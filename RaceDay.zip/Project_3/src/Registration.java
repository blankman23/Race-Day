/**
 * 
 */

/**
 * Shawn Blank
 * 2/19/20
 * CISC 122
 * Project # 3
 * This project will have people registering using their name, age, city, string, and state. 
 * Runners will also be given bibs and times as well
 * Runners results will be posted to a text file.
 * @author blank
 *
 */
public class Registration implements Comparable<Registration>{//start of main method
	//inititializing variables 
	String age=null;
	
	//setting setters and getter to private
	private String firstName=null, gender=null, state=null,city=null, lastName=null, bib=null;
	private double time=0.0;
		
	
/**
 * Registration object 
 * @param firstName
 * @param lastName
 * @param gender
 * @param age
 * @param city
 * @param state
 * @param bib2
 * @param time
 */
public Registration(String firstName, String lastName, String gender, String age, String city, String state, String bib, double time){//start 
	
	//super used to extend to other classes
	super();
	this.firstName=firstName;
	this.gender=gender;
	this.state=state;
	this.city=city;	
	this.lastName=lastName;
	this.age=age;
	this.bib = bib;
	this.time=time;
	}//end
/**
 * comparing the times and sorting them in order using compareTo
 * 
 *  */
public int compareTo(Registration sort) {
    int res = 0;
    if (this.getTime() < sort.getTime()) {
        res =- 1;
    }
    if (this.getTime() > sort.getTime()) {
        res = 1;
    }
    return res;
}

/**
 * to string made in order to print out statement in order
 */
public String toString(){//start of to string
	
	return "First Name:" + this.getfirstName()+ ", lastName:"+ this.getLastName() + ", Gender:" + this.getGender() +
	", age:" + this.getAge() + ", city:" + this.getCity() + ", state:" + this.getState()+", Bib#:"+ this.getBib() + ", Time:"+ String.format("%.2f", this.getTime());
}//end of to string
	
/**
 * @return the bib
 */
public String getBib() {
	return bib;
}
/**
 * @param bib the bib to set
 */
public void setBib(String bib) {
	this.bib = bib;
}

/**
 * @return the lastName
 */
public String getLastName() {
	return lastName;
}
/**
 * @param lastName the lastName to set
 */
public void setLastName(String lastNam) {
	this.lastName = lastNam;
}
/**
 * @return the firstName
 */
public String getfirstName() {
	return firstName;
}
/**
 * @param firstName the firstName to set
 */
public void setfirstName(String firstName) {
	this.firstName = firstName;
}
/**
 * @return the age
 */
public String getAge() {
	return age;
}
/**
 * @param age the age to set
 */
public void setAge(String age) {
	this.age = age;
}
/**
 * @return the gender
 */
public String getGender() {
	return gender;
}
/**
 * @param gender the gender to set
 */
public void setGender(String gender) {
	this.gender = gender;
}
/**
 * @return the city
 */
public String getCity() {
	return city;
}
/**
 * @param city the city to set
 */
public void setCity(String city) {
	this.city = city;
}
/**
 * @return the state
 */
public String getState() {
	return state;
}
/**
 * @param state the state to set
 */
public void setState(String state) {
	this.state = state;
}
/**
 * 
 * @return
 */
public double getTime() {
	
	return time;
}
/**
 * 
 * @param time
 */
public void setTime(double time) {
	
	this.time=time;
}

}//end of main
