
import java.io.*;
import java.util.*;
/**
 * 
 */

/**
 * @author blank
 *extending the attributes of RaceDay to results 
 */
public class results extends RaceDay{//start of class
	
//Registration object ArrayList created 
static ArrayList<Registration> finalList = new ArrayList<Registration>();
	
	/**
	 * @param args
	 * @throws IOException 
	 *calling methods through main
	 */
public static void main(String[] args){//start of main
	//checkin method stores data to the runnerList arrayList
	checkIn(runnersList); 
		
	//RaceResults file read and stored into the FinaList arrayList
	finalList=readResults("../RaceResults.txt");//
		
	// Add all items in runnerList to the list pulled from reading the file	
    for (Registration runner : runnersList) {//start of forloop
         finalList.add(runner); 
      }//end of forloop    
      
    //sort results and write to file
	sortedResults(finalList); 
}//end of main
	
   /**
    * readResults method created in order to read the file and store into arrayList
    * @param fileName
    * @return
    */
	private static ArrayList<Registration> readResults(String fileName){//start of method
		//Creating a new arrayList
		ArrayList<Registration>runnerListResults=new ArrayList<Registration>();
		
		//string array created
		ArrayList<String> values = new ArrayList<String>();    	   
		
		try {//start of try   
			
		//storing file in my file 
		File myFile = new File(fileName);
		
		//Scanner to inputFile into variable  
		Scanner inputFile = new Scanner(myFile);
		
			//Read file until there are no more lines left
		   while(inputFile.hasNext()){//Start of while loop
			   
		   //creating new string array called values
           values = new ArrayList<String>();
           
           // parsing the line
           String line = inputFile.nextLine();
           
           //parsing by cammas
           String[] myList = line.split(",", -1);
           
           		//forloop used to read the toString and split by camma as well as colon 
           		for (int i = 0; i<8; i++){
           			//storing split lines in value 
           			String value = Arrays.toString(myList[i].split(":")).split(",")[1];
               
           			//used to get the substring of the given string 
           			value = value.substring(0, value.length() - 1);
           			//consuming white space
           			value.replaceAll("\\s+","");
           			//adding to value String arrayList
           			values.add(value);
           		}//end of forloop
           
           	  //getting first name 
	 	      String firstName= values.get(0);
	 	      //getting last name
	 	      String lastName= values.get(1);
	 	      //getting gender 
 		      String gender= values.get(2);
 		      //getting age
 		      String age= values.get(3);
 		      //getting city
		      String city= values.get(4);
		      //getting state
 		      String state= values.get(5);
 		      //getting bib
 		      String bib= values.get(6);
 		      //parsing time to turn to double 
 		      double time= Double.parseDouble(values.get(7));
 		      
              //Storing sorted items in the new registration object   
		      runnerListResults.add(new Registration(firstName, lastName, gender,age, city, state, bib,time));
		      
		    }//end of while loop
		   
		    //close the file 
		   inputFile.close();
		}//end of try
		catch(Exception E) { //end of catch
			System.out.println("File RaceResults.txt Created");
	    }//end of catch
		return runnerListResults;
	}//end of method

	/**
	 * SortedResults method used sort the arraylist and append to a file 
	 * @param finalList
	 * @return
	 */
	private static ArrayList <Registration>sortedResults(ArrayList<Registration> finalList) {//start of method
			//try catch used to catch errors
			try{//start of try
				
				//sort is used to sort the runners times
				Collections.sort(finalList); 
				
				//file writer used to create a new text file 
				FileWriter fwriter= new FileWriter("../RaceResults.txt", false);
				
				//print writer used to write to file
				PrintWriter outPutFile= new PrintWriter(fwriter);
				
				//modified forloop used to print put the arraylist to the file 
				for(Registration runner: finalList){
					
				outPutFile.println(runner.toString());	
			   }//end of for
				
				//closing file
				outPutFile.close();
			}//end of try
			
			//catching exception 
			catch(Exception E) { //start of catch		
				System.out.println("File not read");
			}//end of catch
			// TODO Auto-generated method stub
			return finalList;
			
		}//end of method 

}//end of class
