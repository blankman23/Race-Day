/**
 * 
 */
/**
 * @author blank
 *
 */

/**
 * 
 */
/**
 * @author blank
 *
 */

import java.util.*;
/**
 * Raceday class
 * @author blank
 *
 */
public class RaceDay {// start of main
	//object arrayList made in order to store runner features
 static ArrayList <Registration> runnersList = new ArrayList<Registration>();
	
	/**
	 * 
	 * @param runnerList
	 * @return
	 * method made in order to store runners information in an arrayList
	 */
public static ArrayList<Registration> checkIn(ArrayList<Registration> runnerList){//start of method
		//boolean created
		boolean flag= true;
		//scanner used
		Scanner keyboard = new Scanner(System.in);
		System.out.println("How many runners would you like to have?");
		
		//initializing variable 
		int run = 0;
		
		//try catch to validate user input
		try {//start of try
			run = Integer.parseInt(keyboard.nextLine());
		}//end of try
		//validating if the user enter a number
			catch(NumberFormatException ex) {//start of catch
				
				System.out.println("Please enter a number not a string");
				run = Integer.parseInt(keyboard.nextLine());
			
			}//end of catch
		
		//for loop used to ask how many runners there are
		for(int i=0; i<run ; i++) {//start of for loop
			
			//asking for runners first name 
			System.out.println("What is runner "+ (i + 1) + " first name?");
			String first = keyboard.nextLine();
			
			//asking for runners last name
			System.out.println("What is runner "+ (i + 1) + " last name?");
			String last = keyboard.nextLine();
			
			//asking for runners age 
			System.out.println("What is runner "+ (i + 1) + " age?");		
			String ag =keyboard.nextLine();
			try {//start of try
				
			//flag used to enter while loop
			while(flag) {//start of while
				
				//if number is less than zero or greater than 100 condition is met and user will input again
				if(Integer.parseInt(ag)<=0 || Integer.parseInt(ag)>100){
					//flag is now true, will ask user again
						
					flag = true;
					//asking user again and telling user not a valid age
					System.out.println("please enter a valid age ");
					System.out.println("What is runner "+ (i + 1) + " age?");		
					ag =keyboard.nextLine();
						
					}//end of if 
					else {//start of else
						
						//flag is false will exit loop
						flag = false;
					}//end of else
					
				}//end of while
			}//end of try
			catch(Exception E) {//start of catch
				//catch if not an integer, will ask user to enter Int
				System.out.println("please enter a number not a string ");
				ag =keyboard.nextLine();
			}//end of catch
			
			//asking user for gender
			System.out.println("please enter runner " + (i+1) + " gender, enter M for male or f for female? ");
			String gen = keyboard.nextLine();

			do {//start of do
				
				if(gen.equalsIgnoreCase("M") || gen.equalsIgnoreCase("F")) {//start of if
					//flag used to exit loop
					flag = false;
					
				}//end of if
				else {//start of else
					
					//asking user to enter M for male or F for female 
					System.out.println("Invalid choice, Please enter M for male and F for female");
					gen = keyboard.nextLine();
					
					//flag is now true and will repeat the loop
					flag = true;
					
				}//end of else
			}while(flag);//end of do and flag is true 
					
			//asking for users city
			System.out.println("What is runner "+ (i + 1) + " city?");
			String cit = keyboard.nextLine();
			
			//asking for users state 
			System.out.println("What is runner "+ (i + 1) + " state?");
			String stat = keyboard.nextLine();
			
			//bib number set
			 String bib = String.valueOf(i + 1);
			 
			//giving the runner a random time 
			double time = Math.random() * 100 + 1;
			
			//adding runner data to the arraylist
			runnerList.add(new Registration(first, last, gen,ag, cit, stat, bib,time ));
		}//end of forloop
		
		//closing keyboard 
		keyboard.close();
		return runnerList;
	
	
	
	}
	}
//end of method
	//end of class
	

